const Auction = require('../models/Auction');

const createAuction = async (req, res) => {
  const { title, description, startBid, endDate } = req.body;
  try {
    const auction = new Auction({ title, description, startBid, endDate, createdBy: req.user.id });
    await auction.save();
    res.status(201).json(auction);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
};

const getAuctions = async (req, res) => {
  try {
    const auctions = await Auction.find().populate('createdBy', 'username');
    res.json(auctions);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
};

const updateAuction = async (req, res) => {
  const { id } = req.params;
  const { title, description, startBid, endDate } = req.body;
  try {
    const auction = await Auction.findByIdAndUpdate(id, { title, description, startBid, endDate }, { new: true });
    res.json(auction);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
};

const deleteAuction = async (req, res) => {
  const { id } = req.params;
  try {
    await Auction.findByIdAndDelete(id);
    res.json({ message: 'Auction deleted' });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = { createAuction, getAuctions, updateAuction, deleteAuction };
