const express = require('express');
const { placeBid, getBids } = require('../controllers/bidController');
const auth = require('../middleware/authMiddleware');
const router = express.Router();

router.post('/:auctionId', auth, placeBid);
router.get('/:auctionId', getBids);

module.exports = router;
