const express = require('express');
const { createAuction, getAuctions, updateAuction, deleteAuction } = require('../controllers/auctionController');
const auth = require('../middleware/authMiddleware');
const router = express.Router();

router.post('/', auth, createAuction);
router.get('/', getAuctions);
router.put('/:id', auth, updateAuction);
router.delete('/:id', auth, deleteAuction);

module.exports = router;
