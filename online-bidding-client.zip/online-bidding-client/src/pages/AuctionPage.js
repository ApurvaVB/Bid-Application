import React from "react";
import Navbar from '../components/Navbar/Navbar'; 
import AuctionList from '../components/Home/AuctionList'; 

const AuctionPage = () => {
    return (
        <div>
            <Navbar />
            <AuctionList />
        </div>
    );
};

export default AuctionPage;
