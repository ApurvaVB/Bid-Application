
import React, { useState } from 'react';
import AuctionList from '../components/Home/AuctionList';
import Navbar from '../components/Navbar/Navbar'; 
import LoggedInNavbar from '../components/Navbar/LoggedInNavbar'; 
import './HomePage.css';
const HomePage = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false); 

  const handleLogin = () => {
    setIsLoggedIn(true); 
  };

  const handleLogout = () => {
    setIsLoggedIn(false); 
  };

  return (
    <div className="home-page">
      {isLoggedIn ? (
        <LoggedInNavbar onLogout={handleLogout} />
      ) : (
        <Navbar onLogin={handleLogin} />
      )}
      
      <div className="home-hero-section">
        <div className="hero-content">
          <h1>Your Gateway to Extraordinary Finds</h1>
          <p>Unlock deals, bid smart, and seize the moment with our online bidding bonanza!</p>
          <button className="watch-video">Watch Video</button>
        </div>
        <img src="public/profile.png" alt="Landing" className="hero-image" />
      </div>

      <div className="auction-section">
        <h2>Explore Auctions</h2>
    
        <AuctionList />
      </div>
    </div>
  );
};

export default HomePage;
