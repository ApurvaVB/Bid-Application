import React from 'react';
import Profile from '../components/Profile/Profile';

const ProfilePage = () => {
    return (
        <div className="container">
            <Profile />
        </div>
    );
};

export default ProfilePage;
