import React from "react";
import './LandingPage.css'; 
const LandingPage = () => {
    return (
        <div className="landing-page">
            <div className="landing-content">
                <h1>Your Gateway to Extraordinary Finds</h1>
                <p>Unlock deals, bid smart, and seize the moment with our online bidding bonanza!</p>
                <button className="watch-video">Watch Video</button>
                <div className="testimonials">
                    <div className="testimonial">Seamless, lightweight! Loving this site.</div>
                    <div className="testimonial">Overall fantastic!</div>
                </div>
            </div>
            <div className="explore">
                <h2>Explore Auctions</h2>
             
            </div>
        </div>
    );
};

export default LandingPage;
