import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Login.css";
import loginImage from '../../images/loginImage.png';
import logo from '../../images/Vectorphoto.png';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleSubmit = async (event) => {
    event.preventDefault();
    
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();
      if (res.ok) {
        localStorage.setItem('token', data.token); // Store the JWT in local storage
        navigate('/'); // Redirect to homepage after successful login
      } else {
        setError(data.message || 'Login failed');
      }
    } catch (err) {
      setError('Something went wrong. Please try again.');
    }
  };

  return (
    <div className="login-container">
      <div className="login-form-container">
        <div className="login-logo-container">
          <img src={logo} alt="Genix Auctions" className="login-logo" />
          <span className="logo-text">Genix Auctions</span>
        </div>
        <h2>Login</h2>
        <p>Welcome back! Enter your credentials to access your account</p>

        {error && <p className="error-message">{error}</p>}

        <form className="login-form" onSubmit={handleSubmit}>
          <label>Email Address</label>
          <input 
            type="email" 
            placeholder="hello@example.com" 
            required 
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />

          <label>Password</label>
          <input 
            type="password" 
            placeholder="Password" 
            required 
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          <div className="login-options">
            <div className="keep-signed-in">
              <input type="checkbox" id="keep-signed-in" />
              <label htmlFor="keep-signed-in">Keep me signed in</label>
            </div>
            <a href="/forgot-password">Forgot Password</a>
          </div>

          <button type="submit" className="btn-continue">Continue</button>

          <p>or sign up with</p>
          <div className="social-signup">
            <button type="button" className="btn-social">Google</button>
            <button type="button" className="btn-social">Apple</button>
            <button type="button" className="btn-social">Facebook</button>
          </div>

          <p>
            Don’t have an Account? <a href="/sign-up">Sign up here</a>
          </p>
        </form>
      </div>
      
      <div className="login-image-container">
        <img src={loginImage} alt="Illustration" />
      </div>
    </div>
  );
};

export default Login;
