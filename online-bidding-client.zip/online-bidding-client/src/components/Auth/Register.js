import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Register.css";
import logo from '../../images/Vectorphoto.png';
import RegisterImage from '../../images/Imagephoto.png';

const Signup = () => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleSubmit = async (event) => {
    event.preventDefault();

    if (password !== confirmPassword) {
      setError("Passwords don't match");
      return;
    }


    setError(null);

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          firstName,
          lastName,
          email,
          password,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        navigate('/login');
      } else {
        setError(data.message || 'Registration failed');
      }
    } catch (err) {
      setError('Something went wrong. Please try again.');
    }
  };

  return (
    <div className="signup-container">
      <div className="signup-form-container">
        <div className="login-logo-container">
          <img src={logo} alt="Genix Auctions" className="login-logo" />
          <span className="logo-text">Genix Auctions</span>
        </div>
        <h2>Sign up</h2>
        <p>
          New bidders, as soon as you have submitted your information you will
          be eligible to bid in the auction.
        </p>

        {error && <p className="error-message">{error}</p>}

        <form className="signup-form" onSubmit={handleSubmit}>
          <div className="form-group">
            <label>First Name</label>
            <input 
              type="text" 
              placeholder="Olivia" 
              required 
              value={firstName}
              onChange={(e) => setFirstName(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label>Last Name</label>
            <input 
              type="text" 
              placeholder="Rhye" 
              required 
              value={lastName}
              onChange={(e) => setLastName(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label>Email Address</label>
            <input 
              type="email" 
              placeholder="olivia@trustedbid.com" 
              required 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label>Password</label>
            <input 
              type="password" 
              placeholder="Password" 
              required 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label>Confirm Password</label>
            <input 
              type="password" 
              placeholder="Confirm Password" 
              required 
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
            />
          </div>

          {error && password !== confirmPassword && (
            <span className="error-text">Passwords don't match</span>
          )}

          <div className="form-group-checkbox">
            <input type="checkbox" id="receive-updated-emails" />
            <label htmlFor="receive-updated-emails">Receive updated emails</label>
          </div>

          <button type="submit" className="submit-button">Submit</button>

          <div className="divider">or sign up with</div>

          <div className="social-login">
            <button type="button" className="social-btn google-btn">Google</button>
            <button type="button" className="social-btn apple-btn">Apple</button>
            <button type="button" className="social-btn facebook-btn">Facebook</button>
          </div>

          <p className="auction-rules-link">
            Want to know more? <a href="/auction-rules">Auction rules</a>
          </p>
        </form>
      </div>

      <div className="signup-illustration">
        <img src={RegisterImage} alt="Signup illustration" />
      </div>
    </div>
  );
};

export default Signup;
