import React, { useState } from 'react';
import './LandingPage.css';
import Navbar from '../Navbar/Navbar';
import LoggedInNavbar from '../Navbar/LoggedInNavbar';
import landingImage from '../../images/profile.png';
import AuctionList from '../Home/AuctionList';
import Footer from '../Footer/Footer';
import Signup from '../Auth/Register';
import { useNavigate } from 'react-router-dom';

const LandingPage = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showSignup, setShowSignup] = useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    setIsLoggedIn(false);
  };


  const handleLoginClick = () => {
    navigate('/login'); 
  };

  const handleBackToLanding = () => {
    setShowSignup(false);
  };

  return (
    <div>
      {isLoggedIn ? (
        <LoggedInNavbar onLogout={handleLogout} />
      ) : (
        <Navbar onLoginClick={handleLoginClick} />
      )}

      {showSignup && <Signup onBackToLanding={handleBackToLanding} />}

      {!showSignup && (
        <>
          <div className="landing-content landing-page">
            <div className="text-section">
              <p className='heading'>Your Gateway </p>
                <p className='heading'>to Extraordinary </p>
                <p className='heading'>Finds</p>
              <p className='offer'>Unlock deals, bid smart, and seize the moment <br/>with our online bidding bonanza!</p>
              <button className="watch-video" onClick={handleLoginClick}>Watch Video</button>
             
            </div>
            <img  src={landingImage} alt="Landing" className="landing-image" />
          </div>

          <div className="explore-auctions">
            <h2>Explore Auctions</h2>
            <AuctionList />
            <Footer/>
          </div>
        </>
      )}
    </div>
  );
};

export default LandingPage;
