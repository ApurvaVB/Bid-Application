import React from 'react';
import './Profile.css';

const Profile = () => {
    return (
        <div className="profile-container">
            <h2>User Profile</h2>
            <p>Username: Olivia</p>
            <p>Email: olivia@example.com</p>
            <button>Edit Profile</button>
        </div>
    );
};

export default Profile;
