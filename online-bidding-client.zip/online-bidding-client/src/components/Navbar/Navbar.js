import React from 'react';
import './Navbar.css';
import logo from '../../images/Vectorphoto.png';

const Navbar = ({ onLoginClick }) => {
  return (
    <nav className="navbar">
      <div className="navbar-logo">
        <img src={logo} alt="Genix Auctions Logo" className="logo-image" />
        <span className="logo-text">Genix Auctions</span>
      </div>
      <div className="navbar-links">
        <a href="#auctions">Auctions</a>
        <a href="#bidding">Bidding</a>
        <a href="#about">About Us</a>
        <a href="#language">English</a>
      </div>
      <div className="navbar-actions">
        <button className="login-btn" onClick={onLoginClick}>Login</button>
        <button className="get-started-btn">Get Started</button>
      </div>
    </nav>
  );
};

export default Navbar;
