
import React from 'react';
import './LoggedInNavbar.css';

const LoggedInNavbar = ({ onLogout }) => {
  return (
    <nav className="navbar">
      <div className="navbar-brand">Genix Auctions</div>
      <ul className="navbar-menu">
        <li>Auctions</li>
        <li>Bidding</li>
        <li>About Us</li>
        <li>
          <div className="dropdown">
            <button className="dropbtn">English</button>
            <div className="dropdown-content">
              <a href="#">English</a>
              <a href="#">Spanish</a>
              <a href="#">French</a>
            </div>
          </div>
        </li>
        <li>
          <div className="profile-dropdown">
            <div className="profile-text">
              <p>Olivia Rhye</p>
              <p>olivia@example.com</p>
            </div>
            <img
              src="/profile.png"
              alt="Profile"
              className="profile-image"
            />
            <div className="dropdown-content">
              <a href="#">View profile</a>
              <a href="#">Settings</a>
              <a href="#">My bids</a>
              <a href="#" onClick={onLogout}>Log out</a>
            </div>
          </div>
        </li>
      </ul>
    </nav>
  );
};

export default LoggedInNavbar;
