import React from 'react';
import './AuctionItem.css';

const AuctionItem = ({ image, title, minBid, currentBid, timeLeft }) => {
  return (
    <div className="auction-item">
      <img src={image} alt={title} className="auction-image" />
      <div className="auction-info">
        <span className="auction-status">Live Auction</span>
        <h3>{title}</h3>
        <p>Minimum Bid: ${minBid}</p>
        <p>Current Bid: ${currentBid}</p>
        <p>Ends in: {timeLeft}</p>
        <button className="bid-button">Bid now</button>
      </div>
    </div>
  );
};

export default AuctionItem;
