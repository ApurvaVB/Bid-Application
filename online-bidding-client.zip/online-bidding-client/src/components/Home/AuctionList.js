import React from 'react';
import './AuctionList.css'; 
const auctionItems = [
    {
      id: 1,
      title: 'Sony Black Headphones',
      minBid: '$100',
      currentBid: '$157',
      imageUrl: 'https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcSdVFKjsgrKsMt37PSUh6HSoc4ansI2rJQ79A7I0dMjuojGiIUQtuDXVQRzHzSf74qkAuHDCLoupOFeqfkmxuHLhSP2iwWgZaEuEGimT6M',
      timeRemaining: 'Ends in 1 day 12h 43m',
    },
    {
      id: 2,
      title: 'Apple AirPod 2nd Gen',
      minBid: '$80',
      currentBid: '$95',
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQqE2fHa-6mLJvnryXdXPtCUVJzo2CuXnnJgQ&s',
      timeRemaining: 'Ends in 1 day 12h 43m',
    },
    {
      id: 3,
      title: 'Mi 20000mAh Power Bank',
      minBid: '$40',
      currentBid: '$46',
      imageUrl: 'https://5.imimg.com/data5/SELLER/Default/2021/3/HO/RV/OV/11813860/grey-1500-mah-power-bank-500x500.jpg', // Updated link
      timeRemaining: 'Ends in 1 day 12h 43m',
    },
    {
      id: 4,
      title: 'Tribit Bluetooth Speaker',
      minBid: '$10',
      currentBid: '$15',
      imageUrl: 'https://m.media-amazon.com/images/I/71b122pwbpL._AC_SL1500_.jpg', // Updated link
      timeRemaining: 'Ends in 1 day 12h 43m',
    },
    {
        id: 5,
        title: 'Sony Black Headphones',
        minBid: '$100',
        currentBid: '$157',
        imageUrl: 'https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcSdVFKjsgrKsMt37PSUh6HSoc4ansI2rJQ79A7I0dMjuojGiIUQtuDXVQRzHzSf74qkAuHDCLoupOFeqfkmxuHLhSP2iwWgZaEuEGimT6M',
        timeRemaining: 'Ends in 1 day 12h 43m',
      },
      {
        id: 6,
        title: 'Apple AirPod 2nd Gen',
        minBid: '$80',
        currentBid: '$95',
        imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQqE2fHa-6mLJvnryXdXPtCUVJzo2CuXnnJgQ&s',
        timeRemaining: 'Ends in 1 day 12h 43m',
      },
      {
        id: 7,
        title: 'Mi 20000mAh Power Bank',
        minBid: '$40',
        currentBid: '$46',
        imageUrl: 'https://5.imimg.com/data5/SELLER/Default/2021/3/HO/RV/OV/11813860/grey-1500-mah-power-bank-500x500.jpg', // Updated link
        timeRemaining: 'Ends in 1 day 12h 43m',
      },
      {
        id: 8,
        title: 'Tribit Bluetooth Speaker',
        minBid: '$10',
        currentBid: '$15',
        imageUrl: 'https://m.media-amazon.com/images/I/71b122pwbpL._AC_SL1500_.jpg', // Updated link
        timeRemaining: 'Ends in 1 day 12h 43m',
      }
  
  ];
  

const AuctionList = () => {
  return (
    <div className="auction-list">
      {auctionItems.map((item) => (
        <div key={item.id} className="auction-item">
       <img
  src={item.imageUrl}
  alt={item.title}
  className="auction-image"
  style={{ width: '110px', height: '100px', marginTop:'10px' }} // Adjust dimensions as needed
/>

          <div className="auction-info">
            <h3>{item.title}</h3>
            <p>Minimum Bid: {item.minBid}</p>
            <p>Current Bid: {item.currentBid}</p>
            <p>{item.timeRemaining}</p>
            <button className="bid-now">Bid Now</button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default AuctionList;
