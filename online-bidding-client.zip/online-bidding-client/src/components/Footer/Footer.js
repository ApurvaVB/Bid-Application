import React from "react";
import "./Footer.css"; 
import logo from '../../images/Vectorphoto.png';

const Footer = () => {
  return (
    <footer className="footer-container">
      <div className="footer-content">
       
        <div className="footer-logo-section">
          <img src={logo} alt="Genix Auctions" className="footer-logo" />
          <span className="footer-company-name">Genix Auctions</span>
        </div>

        <div className="footer-links-section">
          <div className="footer-links">
            <a href="#products">Products</a>
            <a href="#about-us">About us</a>
            <a href="#contact">Contact</a>
          </div>
          <div className="footer-links">
            <a href="#auctions">Auctions</a>
          </div>
          <div className="footer-links">
            <a href="#bidding">Bidding</a>
          </div>
        </div>

    
        <div className="footer-social-section">
          <a href="https://twitter.com" className="social-icon">
            <i className="fab fa-twitter"></i>
          </a>
          <a href="https://facebook.com" className="social-icon">
            <i className="fab fa-facebook"></i>
          </a>
          <a href="https://instagram.com" className="social-icon">
            <i className="fab fa-instagram"></i>
          </a>
          <a href="https://linkedin.com" className="social-icon"> {/* Added LinkedIn icon */}
            <i className="fab fa-linkedin"></i>
          </a>
        </div>
      </div>

 
      <div className="footer-bottom">
        <p>&copy; 2024. All Rights Reserved by Genix</p>
      </div>
    </footer>
  );
};

export default Footer;
